const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const cors = require('cors');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const session = require('express-session');

const app = express();
const port = 4000;

// Middleware
app.use(cors({
  origin: 'http://localhost:4200', // Angular app origin
  credentials: true
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
  secret: 'fashion-secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Set secure: false for localhostHTTP
}));

// MongoDB Connection
const uri = "mongodb://127.0.0.1:27017";
const client = new MongoClient(uri);
let database;
let fashionCollection;

async function connectToDatabase() {
  try {
    await client.connect();
    database = client.db("FashionData");
    fashionCollection = database.collection("Fashion");
    console.log("Connected to MongoDB database: FashionData");

    // Seed Data
    const count = await fashionCollection.countDocuments();
    if (count === 0) {
      const sampleFashions = [
        // Style: Casual
        { title: "Casual T-Shirt", details: "<p>A comfortable cotton t-shirt for daily wear.</p>", thumbnail: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300", style: "Casual", created_at: new Date("2023-01-01") },
        { title: "Denim Jeans", details: "<p>Classic blue denim jeans with a straight fit.</p>", thumbnail: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=300", style: "Casual", created_at: new Date("2023-01-02") },
        { title: "Sneakers", details: "<p>White casual sneakers.</p>", thumbnail: "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=300", style: "Casual", created_at: new Date("2023-01-03") },
        // Style: Formal
        { title: "Business Suit", details: "<p>A sharp 2-piece business suit in charcoal grey.</p>", thumbnail: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=300", style: "Formal", created_at: new Date("2023-01-04") },
        { title: "Silk Tie", details: "<p>A red silk tie to complement any suit.</p>", thumbnail: "https://images.unsplash.com/photo-1550927424-df3594cf481f?w=300", style: "Formal", created_at: new Date("2023-01-05") },
        { title: "Leather Oxfords", details: "<p>Premium leather oxford shoes.</p>", thumbnail: "https://images.unsplash.com/photo-1614252339474-6593b4a20bba?w=300", style: "Formal", created_at: new Date("2023-01-06") },
        // Style: Sportswear
        { title: "Running Jacket", details: "<p>Lightweight windproof running jacket.</p>", thumbnail: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=300", style: "Sportswear", created_at: new Date("2023-01-07") },
        { title: "Yoga Pants", details: "<p>Stretchy and breathable yoga pants.</p>", thumbnail: "https://images.unsplash.com/photo-1608249673981-dce56f5a3db2?w=300", style: "Sportswear", created_at: new Date("2023-01-08") },
        { title: "Sport Socks", details: "<p>Moisture-wicking athletic socks.</p>", thumbnail: "https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?w=300", style: "Sportswear", created_at: new Date("2023-01-09") }
      ];
      await fashionCollection.insertMany(sampleFashions);
      console.log("Seeded database with sample Fashion data.");
    }
  } catch (error) {
    console.error("MongoDB connection error:", error);
  }
}

connectToDatabase();

// --- RESTful APIs ---

// o API returns the entire Fashion, sorted by creation date descending
app.get('/fashions', async (req, res) => {
  try {
    const result = await fashionCollection.find({}).sort({ created_at: -1 }).toArray();
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// o API to filter the list of Fashions according to a certain Style
app.get('/fashions/style/:style', async (req, res) => {
  try {
    const style = req.params.style;
    const result = await fashionCollection.find({ style: style }).sort({ created_at: -1 }).toArray();
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// o API returns a Fashion based on ObjectId (collectively id)
app.get('/fashions/:id', async (req, res) => {
  try {
    const id = req.params.id;
    if (!ObjectId.isValid(id)) {
        return res.status(400).json({ error: "Invalid ID format" });
    }
    const result = await fashionCollection.findOne({ _id: new ObjectId(id) });
    if (result) {
      res.json(result);
    } else {
      res.status(404).json({ message: "Fashion not found" });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// o API to add a new Fashion
app.post('/fashions', async (req, res) => {
  try {
    const newFashion = req.body;
    newFashion.created_at = new Date(); // automatically set creation date
    const result = await fashionCollection.insertOne(newFashion);
    res.status(201).json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// o API to edit a Fashion
app.put('/fashions/:id', async (req, res) => {
  try {
    const id = req.params.id;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    const updateData = req.body;
    delete updateData._id; // Prevent updating the ID itself
    const result = await fashionCollection.updateOne(
      { _id: new ObjectId(id) },
      { $set: updateData }
    );
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// o API deletes a Fashion based on id
app.delete('/fashions/:id', async (req, res) => {
  try {
    const id = req.params.id;
    if (!ObjectId.isValid(id)) {
      return res.status(400).json({ error: "Invalid ID format" });
    }
    const result = await fashionCollection.deleteOne({ _id: new ObjectId(id) });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- Shopping Cart (Session & Cookie based) ---

// Add item to cart session
app.post('/cart', (req, res) => {
  const item = req.body;
  
  // Set a test cookie just to satisfy the cookie programming requirement
  res.cookie('last_added_item', item.title, { maxAge: 900000, httpOnly: false });

  if (!req.session.cart) {
    req.session.cart = [];
  }
  
  // Basic cart logic: add item if not exists
  const exists = req.session.cart.find(c => c._id === item._id);
  if (!exists) {
    req.session.cart.push(item);
  }
  
  res.json({ message: "Item added to cart", cart: req.session.cart });
});

// Get current cart session
app.get('/cart', (req, res) => {
  res.json(req.session.cart || []);
});

// Clear cart session
app.delete('/cart', (req, res) => {
  req.session.cart = [];
  res.json({ message: "Cart cleared" });
});

// --- Start Server ---
app.listen(port, () => {
  console.log(`server-fashion listening at http://localhost:${port}`);
});
